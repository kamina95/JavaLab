package lecture_3;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */

/**
 *Write a Java program which obtains minutes and remaining seconds from an amount of time in second. 
 * For example, 500 seconds contains 8 minutes and 20 seconds. 
 * Using Scanner to prompt the user for an inputs of seconds and calculate the remaining minutes and seconds.
 */
public class MinutesAndSeconds {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter number of secounds");
        int inputSecounds = sc.nextInt();
        
        int minutes = inputSecounds/60; // return the number of minutes from the giving number of secounds
        int secounds = inputSecounds%60; //remaining number of secounds 
        
        
        System.out.println(inputSecounds+ " secounds, comprise of: "+ minutes+" minutes and "+secounds+" secounds");
        
    }
    
}
