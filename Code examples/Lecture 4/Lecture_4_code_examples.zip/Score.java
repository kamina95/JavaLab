package lecture_4;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */

/**
 * Example of if-else  
 */
public class Score {
    public static void main(String[] args) {
        
      
        
        int score =63;
        
        String classification = "";
        
        if(score>=70){
            classification = "First class ";
        }else if (score >=60){
            classification = "Upper second class";
        }else if (score >=50){
            classification = "Lower second class";
        }else if (score >=40){
            classification = "Third";
        }else if (score >=35){
            classification = "Compositable Fail";
        }else {
            classification = "Uncompositable Fail";
        }
        
        System.out.println(classification);
        
        
      
        
    }
    
}
