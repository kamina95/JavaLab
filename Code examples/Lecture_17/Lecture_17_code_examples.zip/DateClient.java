package lecture_17;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import javax.swing.JOptionPane;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class DateClient {
      private static final String SERVER_IP = "127.0.0.1";
      private static final int SERVER_PORT = 9090;
      
    public static void main(String[] args) throws IOException{
      
        
        Socket socket = new Socket(SERVER_IP, SERVER_PORT);
        BufferedReader input = new BufferedReader (new InputStreamReader(socket.getInputStream()));
        
        String serverRespons = input.readLine();
        
        System.out.println(serverRespons);
     
        socket.close();
    }
}
