package lecture_17;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class DateServer {
    private static final int PORT = 9090;
    
    public static void main(String[] args) throws IOException {        
        ServerSocket  listiner = new ServerSocket(PORT);
        System.out.println("Server is waiting for client connection");
        Socket client = listiner.accept();
        System.out.println("server Connect to client");
        PrintWriter out = new PrintWriter (client.getOutputStream(), true);
        out.println(new Date ().toString());
        System.out.println("Send data .Closing ");
        
        client.close();
        listiner.close();
    }
    
}
