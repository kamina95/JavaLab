package lecture_16;

import java.io.File;
import java.io.IOException;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class CreateFile {
    public static void main(String[] args) {
        
        try{
   
           File f = new File ("mytextfile.txt");
           if(f.createNewFile()){
               System.out.println("file created");
           }else{
               System.out.println("file already exists");
           }
            
        }catch (IOException e){
               System.out.println("file not found");
        }
        
        
        
        
    }
    
}
