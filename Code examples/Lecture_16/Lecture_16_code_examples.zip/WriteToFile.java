package lecture_16;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class WriteToFile {
    public static void main(String[] args) {
        try{
           FileWriter writer = new FileWriter("mytextfile.txt"); 
           writer.write("Great poem");
           writer.close();
            System.out.println("Seccesfully wrote to the file");
        }catch(IOException e){
            System.out.println(""+e.toString());
        }
       
    }
    
}
