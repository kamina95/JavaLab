package lecture_16;

import java.io.File;
import java.util.ArrayList;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class FileInformation {
    public static void main(String[] args) {
          File f = new File ("mytextfile.txt");
          if(f.exists()){
              System.out.println("File name: "+ f.getName());
              System.out.println("Absolut path "+ f.getAbsolutePath());
              System.out.println("WriteTable: "+f.canWrite());
              System.out.println("Readable: "+f.canRead());
              System.out.println("File size in bytes: "+f.length());
          }else{
              System.out.println("file does not exists");
          }
    }
    
}
