package lecture_16;

import java.io.Serializable;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class Sandwich implements Serializable {

    private String bread;
    private String cheese;

    public Sandwich() {
    }

    public Sandwich(String bread, String cheese) {
        this.bread = bread;
        this.cheese = cheese;
    }

    public String getBread() {
        return bread;
    }

    public void setBread(String bread) {
        this.bread = bread;
    }

    public String getCheese() {
        return cheese;
    }

    public void setCheese(String cheese) {
        this.cheese = cheese;
    }

}
