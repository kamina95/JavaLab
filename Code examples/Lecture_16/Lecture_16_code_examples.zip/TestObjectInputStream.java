package lecture_16;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class TestObjectInputStream {

    public static void main(String[] args)
            throws ClassNotFoundException, IOException {
        try ( 
                ObjectInputStream input
                = new ObjectInputStream(new FileInputStream("object.dat"))) {
            Sandwich sandwich = (Sandwich) input.readObject();
            System.out.println(sandwich.getBread());
            System.out.println(sandwich.getCheese());
        }
    }
}