package lecture_12;

import java.util.Date;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class Main {
    public static void main(String[] args) {    
        displayObject (new Circle (1, "red", false));
        displayObject (new Rectangle (1, 1, "black", true));
        
    }

    public static void displayObject(GeometricObject object){
        System.out.println("Created on: "+ object.getDate()+
                "Colour is: "+object.getColor());
    }
    
}
