package lecture_12;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class Rectangle extends GeometricObject{

    private double width;
    private double height;
 
    public Rectangle(){
        
    }
    public Rectangle(double width, double height, String color, Boolean b) {
        this.width = width;
        this.height = height;
        setColor(color);
        setFilled(b);
    }
    
    
    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }
    public double getArea(){
        return width * height;
    }

    public double getPerimeter (){
        return 2 * (width + height);
    }
  
    public String toString() {
        return super.toString()+"Rectangle{" + "width=" + width + ", height=" + height + '}';
    }
    
    
}
