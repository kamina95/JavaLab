package lecture_14_15;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class TilePaneExample extends Application{

    @Override
    public void start(Stage primaryStage){
        
         TilePane tile = new TilePane();
         
         Button top = new Button("Top");
         Button left = new Button("Left");
         Button center = new Button("Center");
         
            tile.setPadding(new Insets(10, 10, 10, 10));
            tile.setPrefColumns(2);
            tile.setStyle("-fx-background-color: #CD5C5C;");
            HBox hbox2 = new HBox(8); // spacing = 8
            hbox2.getChildren().addAll(top, left, center);
            tile.getChildren().add(hbox2);

        Scene s = new Scene(tile, 200,250);
        primaryStage.setTitle("Tile Pane");
        primaryStage.setScene(s);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    } 
}
