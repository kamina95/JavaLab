package lecture_14_15;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class FlowPaneExample extends Application{

    @Override
    public void start(Stage primaryStage){
         FlowPane flow = new FlowPane();
         Button left = new Button("Left");
         Button center = new Button("Center");
        
         flow.setPadding(new Insets(10, 10, 10, 10));
        flow.setStyle("-fx-background-color: DAE6F3;");
        flow.setHgap(5);
        flow.getChildren().addAll(left, center);
        
        Scene s = new Scene(flow, 200,250);
        primaryStage.setTitle("FlowPane");
        primaryStage.setScene(s);
        primaryStage.show();  
    }
    public static void main(String[] args) {
        launch(args);
    } 
}
