package lecture_7;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class CountNumbersInText {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter your password. Please remember that the pasword should include some numbers");
        String password = sc.next();
        System.out.println("the password has: "+coutNumbers(password)+ "digits in it");
          
    }
    
    public static int coutNumbers(String n){
        
        int numOrDigits = 0;
        
        for (int i = 0; i < n.length(); i++) {
   
                if ( Character.isDigit(n.charAt(i))){
                    
                    numOrDigits =numOrDigits+ 1;
                }
               
            }
       return numOrDigits;
            
       
        
         
     
    }
    
}
