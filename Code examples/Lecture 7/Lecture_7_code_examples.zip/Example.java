package lecture_7;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class Example {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        
        
       
        
        System.out.println(mileToKilometer(1));
       
       
        
    }
    
    
    
    public static double mileToKilometer(double mile){
        double km =0;
        
        km = mile *1.609;
        
        return km;
    }
    
    public static double kmToMiles(double mile){
        double km =0;
        
        km = mile *1.609;
        
        return km;
    }
    
    
}
