package lecture_7;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class Password {
    public static void main(String[] args) {
        
        
        
        String password = "Password123.mdx.ac.uk.NW4";
        
        int numOrDigits = 0;
        for (int i = 0; i < password.length(); i++) {
   
                if ( Character.isDigit(password.charAt(i))){
                    
                    numOrDigits =numOrDigits+ 1;
                }
               
            }
        System.out.println("the number of digit in the password is: "+ numOrDigits);
    }
    
}
