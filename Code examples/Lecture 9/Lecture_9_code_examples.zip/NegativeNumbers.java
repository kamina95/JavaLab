package lecture_9;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */

// This program counts the number of negative numbers in 2D array

public class NegativeNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        
        int [] []  numbers ={
                {-4, -3, -1, 1},
                {-2, -2, 1, 2},
                {-1, 1, 2, 3},
                {1, 2, 4, 5}};
        
        int count =0;
        for (int row = 0; row < numbers.length; row++) {
            for (int col = 0; col < numbers[0].length; col++) {
                 if (numbers[row][col]<0){
                count = count+1;
            }   
            }
            
        }
        System.out.println("the number of negative numbers in it is: "+ count);
    }
    
}
