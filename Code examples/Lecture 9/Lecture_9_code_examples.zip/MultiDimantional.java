package lecture_9;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class MultiDimantional {
    public static void main(String[] args) {
        
        int [][] rents = {
            {400, 500, 600},
            {350, 425, 670},
            {560, 230, 410}};
        
        System.out.println("Jan\tFeb\tMarch");
        
        for (int row = 0; row < rents.length; row++) {
            for (int col = 0; col < rents[0].length; col++) {
                System.out.print("£"+rents[row][col]+"\t");
                
            }
            System.out.println(""+row);
            
        }
        
    }
    
}
