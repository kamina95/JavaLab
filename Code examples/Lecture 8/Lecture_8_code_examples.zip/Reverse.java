package lecture_8;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class Reverse {
    public static void main(String[] args) {
         int [] n = {100,6,8,76,3,9,5,7};
        
            for (int e : reverse(n)){
                System.out.println(e);
            }
        
        }   
    public static int[] reverse(int []list){
        int [] result = new int [list.length];
        for (int i = 0, j=result.length-1; i < result.length; i++,j--) {
            result[j]= list[i];           
        }       
        return result;
    }
    
 
    
}
