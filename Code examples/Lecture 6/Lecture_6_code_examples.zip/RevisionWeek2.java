
package week6_lecture;

/**
 * in week 2 we did  
 * char and String, Concatenation
 * 
 * 
 * @author Anna29
 */
public class RevisionWeek2 {
    
    public static void main(String[] args) {
        
        //defining a variable types of char
        char letter1;
        char letter2;
        
        //assigning value to the variable
        letter1  = 'a';
        letter2 = '2';
        
        //declering variable a types of String
        String tool;
        
        //assigning value to the variable
        tool = "screwdriver";
        
        //concatenating two variables (letter1 and tool) into one String
        String solution = letter1 + " " + tool;
        
        //printing the concatenated solution into the console
        System.out.println("the tool I was looking for is a: "+ solution);
        
    
        
    }
}
