package lecture_6;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class RevisionWeek5_1 {
    
    public static void main(String[] args) {
        
        int number1 = 10;
        int number2 = 15;
        int temp;
        
       // number1 = number2;  // cannot swap by doing this
        
        System.out.println("Initialy, number1 = "+number1 + " number2 "+number2);
        
        if (number1 < number2){
            
            temp = number1;
            number1 = number2;
            number2 = temp;
            
        }
        
        System.out.println("After swaping, number1 = "+number1 + " number2 "+number2);
        
        
        
    }
    
}
