
package week6_lecture;

/**
 * In week 1 we cover print and println statments the diffrence between thous two is that:
 * print would print on the some line and the println statment would reprint on seperate line
 * 
 */
public class RevisionWeek1 {
    
    public static void main(String[] args) {
        
        System.out.print("Hello"); //print would stay at the sam line 
        System.out.println(" World"); //it would print on seperate line and the coursore will move to a new line
    
       
    
    }
}
