package lecture_6;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class RevisionWeek5_2 {
    
    
    public static void main(String[] args) {
        
       
    }
    
}
