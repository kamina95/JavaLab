package lecture_6;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class RevisionWeek5 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        System.out.println("Enetr 1st number to sum, If you want to stop just enter -1");
        int number = sc.nextInt();
        int sum =0;
        
        while (number != -1){
                sum = sum +number;
                System.out.println("the sum vale is: "+sum); 
             
                System.out.println("Enetr next number");
                number = sc.nextInt();
                    
        }
        
        System.out.println("the sum vale is: "+sum);
        
    }

    
}
