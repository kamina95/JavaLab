package lecture_10;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class CircleTester {
    
    public static void main(String[] args) {
        
        Circle c =  new Circle();
        c.setRadious(10);
        System.out.println(""+c.numberOfObjects);
        System.out.printf("%.2f",c.getArea()); 
        System.out.println("\n"+c);
        
        Circle c2 = new Circle(5);
        System.out.println(c2.numberOfObjects+"\n");
        System.out.printf("\n%.2f",c2.getArea()); 
        
    }
    
    
}
