package lecture_10;

import java.time.LocalDate;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class Date {
    int day;
    int month;
    int year;
    
    public Date(){
       
        LocalDate myObj = LocalDate.now();
        day = myObj.getDayOfMonth();
        month = myObj.getMonthValue();
        year = myObj.getYear();
    }
    
    public Date(int day, int month, int year) {
    this.day = day;
    this.month = month;
    this.year = year;
    }
    
    public String toString(){
        return ""+ day+"/"+month+"/"+year;
    }
    
    
    
}
