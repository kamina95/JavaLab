package lecture_13;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class Exception   {
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        int num1=0;
        
        while(true){
          
        try{
              num1 = sc.nextInt();
              break;
        }catch(java.util.InputMismatchException e){
            System.out.println("enter a number");
            sc.nextLine();
        }
        System.out.println(num1);
    }
        
      
        
        
    }
    
    
}
