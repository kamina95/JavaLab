package lecture_5;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class YesNoRepeat {
    
    public static void main(String[] args) {
        
        char ans = 'y';
        Scanner sc = new Scanner (System.in);
        
        ///using while loop
        while (ans=='Y' || ans== 'y' ){
            System.out.println("Welcome to Java ");
            
            System.out.println("Do you want to repeat ? (Y/N)");
            ans = sc.next().charAt(0);
        }
        
        
        // using do while loop
         do {
            System.out.println("Welcome to Java ");
            
            System.out.println("Do you want to repeat ? (Y/N)");
            ans = sc.next().charAt(0);
            
            
        }while (ans=='Y' || ans== 'y' );
        
    }
    
    
}
