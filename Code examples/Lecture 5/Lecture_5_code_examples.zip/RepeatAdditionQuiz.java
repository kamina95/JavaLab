package lecture_5;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class RepeatAdditionQuiz {
    public static void main(String[] args) {
        
        int number1 = (int)(1+Math.random()*10);
        int number2 = (int)(1+Math.random()*10);
        
        Scanner sc = new Scanner (System.in);
        
        System.out.println("What is: "+ number1 + " + "+number2+" ?");
        int answer = sc.nextInt();
        
        while(number1+number2!=answer){
            System.out.println("Wrong answer try again.\n What is: "+ number1 + " + "+number2+" ?");
            answer = sc.nextInt();
        }
        
        System.out.println("Well done you got it");
        
    }
    
}
