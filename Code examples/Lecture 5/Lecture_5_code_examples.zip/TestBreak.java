package lecture_5;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class TestBreak {
    public static void main(String[] args) {
        
        int sum =0;
        int number =0;
        
        while (number < 20){
            number++;
            
            
            if (number == 10 || number == 11)
                continue;
                System.out.println("number-"+ number);
                sum += number;
                
        }
        
        System.out.println("the sum vale is: "+sum);
        
    }
    
}
