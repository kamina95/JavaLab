package lecture_5;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class SumGivingNumbers {
    public static void main(String[] args) {
        int data, sum =0;
        
        Scanner sc = new Scanner (System.in);
                
        do{
            System.out.println("Enter an integer number (the input ends if it is 0):/nThe sum is: "+sum);
            data = sc.nextInt();
            sum += data;
            
        }while(data != 0);
        
        System.out.println("The sum is: "+ sum);
    }
    
}
