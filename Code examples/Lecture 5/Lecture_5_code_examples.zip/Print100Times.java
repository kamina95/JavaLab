package lecture_5;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */
public class Print100Times {
    public static void main(String[] args) {
        
        for (int i = 0; i < 100; i++) {
            System.out.println(i + "- I love programming!" );
            
        }
        
    }
    
}
