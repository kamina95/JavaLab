package lecture_5;

import java.util.Scanner;

/**
 *
 * Exercises prepared basing on the book:
 * “Introduction to Java Programming and Data Structure”
 * Eleventh Edition by Y. Daniel Liang
 */

/**
 * Swapping between two numbers
 */
public class Swapping {
    
    public static void main(String[] args) {
    
     int num1 =100;
     int num2 = 30;
     int temp;
     
     System.out.println("Before swapping = num1: "+num1+" num2: "+ num2);
     
     temp = num2;
     num2 = num1;
     num1 = temp;
       
     System.out.println("After swapping = num1: "+num1+" num2: "+ num2);   
    }
    
}
